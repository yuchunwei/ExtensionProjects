#include "../util/util.h"

class p1{
public:
	void print_usa();
	void print_n_n2_n3();
	void a_power_b();
	void two_power_n();
	void a1(int start, int end);
	void a2(int start, int end);
	void a3(int start, int end);
	void a4(int start, int end);
	void riceOnChessBoard(int board_num);
};